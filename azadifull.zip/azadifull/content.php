<article>
		
	<?php while(have_posts()) : the_post(); ?>
		<seciton class="post">
			    <div class="post-counter"></div>
                <div class="post-content">
                    <a href="<?php the_permalink(); ?>"><h1><?php the_title(); ?></h1></a>
                    <p class="post-summary">
                    <?php the_field('post_summary'); ?>
                    </p>
                </div>
				
				<div class="post-info">
                    <p class="post-coms">
                        <?php
                        comments_popup_link( 'আলোচনায় অংশ নিন', '১ জন আলোচনায় আছেন', '% জন আলোচনায় আছেন', '', 'আলোচনা বন্ধ ');
                        ?>
                    </p>
                    
                    <p class="post-tags"><?php the_tags('','',''); ?></p>

				</div>
		</seciton>
		
	<?php endwhile; ?>
		

	</article>