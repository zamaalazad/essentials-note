<?php get_header(); ?>

	<?php get_template_part('content'); ?>


	<section class="panel">
			
			<?php the_posts_pagination(array(
				'mid_size' => 1,
				'prev_text' => '<p class="inter_link">Newer Articles</p>',
				'next_text' => '<p class="inter_link">Older Articles</p>',
				'screen_reader_text' => ' ',
			)); ?>

	</section>
	

<?php get_footer(); ?>