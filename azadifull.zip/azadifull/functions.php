<?php

    function basic_template_settings(){

        //RSS Feed Links generated

        add_theme_support('automatic-feed-links');

        // Title Tag add here

        add_theme_support('title-tag');

        //Custom Background here

        add_theme_support('custom-background');

        //Custom Logo Here

       add_theme_support('custom-logo');

        //Register Menu Here
        
		register_nav_menus(array(
			'primary' => 'Main Menu',
			'social' => 'Social Menu',
			'footer' => 'Footer Menu'
		));

    }

    add_action('after_setup_theme', 'basic_template_settings');



    // Script Including

    function azadi_script(){

        //Main StyleSheet URI

        wp_enqueue_style('mainstyle', get_stylesheet_uri());

        // Font Awesome URI

        wp_enqueue_style('fontAwesome', get_template_directory_uri()."/css/font-awesome.min.css");

        //Responsive Stylesheet URI 
        
        wp_enqueue_style('responsive', get_template_directory_uri()."/responsive.css");


    }

    add_action('wp_enqueue_scripts', 'azadi_script');



?>