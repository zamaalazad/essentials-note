<!DOCTYPE html>
<html <?php language_attributes();?> >
<head>
	<meta charset= "<?php bloginfo('charset'); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale= 1.0, maximum-scale=1.0, user-scalable=no" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	
	<header>

		
		<section class="brand">
			<?php $custom_logo_id = get_theme_mod( 'custom_logo' );
			$logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
			?>
			
			<a href="<?php bloginfo('home'); ?>">
				<?php if ( has_custom_logo() ) {
						echo '<img src="'. esc_url( $logo[0] ) .'">';
				} else {
						echo '<img src="'. get_stylesheet_directory_uri() . '/img/logo.svg' .'">';
				} ?>
			</a>
			<a href="<?php bloginfo('home'); ?>" ><h2><?php bloginfo('name'); ?></h2></a>
			
		</section>

		<nav>
			<?php wp_nav_menu(array(
					'theme_location' => 'primary',
					'menu_class' => 'inter_link'
			));?>
		</nav>


	</header>