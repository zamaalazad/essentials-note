<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale= 1.0" />
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/responsive.css">
	<?php wp_head(); ?>
</head>
<body>

<main>
	
	<header>

		
		<section class="brand">
			<img src="<?php echo get_template_directory_uri(); ?>/img/logo.svg" alt="logo">
			<h2>S Design House</h2>
		</section>
		<nav>
			<ul class="inter_link">
				<li><a href="<?php bloginfo('home'); ?>">Articles</a></li>
				<li><a href="">Videos</a></li>
				<li><a href="">Podcasts</a></li>
			</ul>
		</nav>


	</header>