<?php


    add_theme_support('title-tag');
    add_theme_support('post-thumbnail');


    