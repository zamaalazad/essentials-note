<?php require_once('header.php'); ?>




<section class="article">

    

    <h1>কম্পিউটার প্রযুক্তি এবং বাংলাদেশে কম্পিউটার</h1>
    <section class="summary"> 
        <p>
            দৈনন্দিন জীবনে কম্পিউটারের গুরুত্ব অপরিসীম সেটা আমরা সবাই জানি কিন্তু আমরা কতটুকু কম্পিউটার ইউজ করতে পারি
        </p>
    </section>  

    <div class="post-info">

        <p class="inter_link"><a href="">AI</a> <a href="">Podcasts</a></p>
        <p class="inter_link"><a href=""><span>15</span>Conversations</a></p>

    </div>
    

	<img class="full" src="<?php echo get_template_directory_uri(); ?>/img/4.png" alt="">
    

    <section class="para">   
        <p>
            দৈনন্দিন জীবনে কম্পিউটারের গুরুত্ব অপরিসীম সেটা আমরা সবাই জানি কিন্তু আমরা কতটুকু কম্পিউটার ইউজ করতে পারি বা ব্যবহার করতে জানি বলা যায় বেশিরভাগ ব্যবহারকারী সাধারণ ব্যবহারকারী হিসেবে আছে যেমন যারা মূলত বিদেশে থাকে এবং যারা বেশিরভাগ সময় থাকে মানে গার্লফ্রেন্ড গুলোতে সেগুলোতে থাকাকালে অনেকে কম্পিউটার ইউজ করে থাকেন যেমন অনেককে দেখা যায় বাড়িতে আসার সময় একটা ল্যাপটপ বা ট্যাবলেট কম্পিউটার নিয়ে আসেন এখন প্রশ্ন হচ্ছে ওই কম্পিউটার বা ট্যাবলেট ব্যবহারকারী কি কাজে ব্যবহার করে থাকেন।
        </p>
    </section> 
    <img class="square" src="img/3.jpg" alt="">

	<section class="para size">   
        <p>
            দৈনন্দিন জীবনে কম্পিউটারের গুরুত্ব অপরিসীম সেটা আমরা সবাই জানি কিন্তু আমরা কতটুকু কম্পিউটার ইউজ করতে পারি বা ব্যবহার করতে জানি বলা যায় বেশিরভাগ ব্যবহারকারী সাধারণ ব্যবহারকারী হিসেবে আছে যেমন যারা মূলত বিদেশে থাকে এবং যারা বেশিরভাগ সময় থাকে মানে গার্লফ্রেন্ড গুলোতে সেগুলোতে থাকাকালে অনেকে কম্পিউটার ইউজ করে থাকেন যেমন অনেককে দেখা যায় বাড়িতে আসার সময় একটা ল্যাপটপ বা ট্যাবলেট কম্পিউটার নিয়ে আসেন এখন প্রশ্ন হচ্ছে ওই কম্পিউটার বা ট্যাবলেট ব্যবহারকারী কি কাজে ব্যবহার করে থাকেন।
        </p>
		<section class="details">
			<h4>Background</h4>
			<ul class="inter_link">
				<li><a href="">Background-color</a></li>
				<li><a href="">Background-image</a></li>
				<li><a href="">Background-size</a></li>
				<li><a href="">Background-attachment</a></li>
				<li><a href="">Background-position</a></li>
			</ul>	
		</section>
    </section> 
    <!-- <section class="sidebar"></section> -->
</section>





<?php get_footer(); ?>