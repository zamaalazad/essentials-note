
	<footer>
		
		<section class="foo">
			<section class="info">
				<p class="inter_link"><a href="<?php bloginfo('home') ?>">Azadi</a> <i class="fa fa-angle-right"></i> <a href="">Article</a></p>
			</section>
			
			<section class="social">
				<ul>
					<li><i class="fa fa-facebook-square"></i><a href="">FaceBook</a></li>
					<li><i class="fa fa-github"></i><a href="">GitHub</a></li>
					<li><i class="fa fa-codepen"></i><a href="">CodePen</a></li>
				</ul>

			</section>
			<section class="contact-info">
				<p class="inter_link"><a href="mailto:azadiduniya@gmail.com">Say Hello!</a></p>
			</section>
		</section>
	</footer>

</main>
<?php wp_footer(); ?>
</body>
</html>