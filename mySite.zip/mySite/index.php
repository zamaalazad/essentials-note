<?php get_header(); ?>

	<article>
		

		<seciton class="post">
			<div class="post-counter"></div>
			<section class="post-element">
				<div class="post-info">

				<p class="inter_link"><a href="">Developments</a></p>
				<p class="inter_link"><a href=""><span>15</span>Conversations</a></p>
				
				</div>

				<a href="single.php"><h1>কম্পিউটার প্রযুক্তি এবং বাংলাদেশে কম্পিউটার</h1></a>
				<p>
				সম্পূর্ণরূপে কম্পিউটারকে কিভাবে দৈনন্দিন কাজে লাগানো যায়
				</p>
			</section>
		</seciton>

		<seciton class="post">
			<div class="post-counter"></div>
			<section class="post-element">
				<div class="post-info">
					<p class="inter_link"><a href="">Design</a></p>
					<p class="inter_link"><a href=""><span>15</span>Conversations</a></p>
					
				</div>

				<a href="single.php"><h1>making a minimalistic design</h1></a>

				<p>
					A ground up redesign for <a href="">Zahner's flagship website</a>.
				</p>
			</section>
		</seciton>

		<seciton class="post">
			<div class="post-counter"></div>
			<section class="post-element">
			<div class="post-info">
				<p class="inter_link"><a href="">Design</a></p>
				<p class="inter_link"><a href=""><span>15</span>conversations</a>
			</div>

			<a href="single.php"><h1>post design for blog design</h1></a>
			<p>
				Developing a digital platform for <a href="">MIT</a>'s new Design Lab.
			</p>
			</section>
		</seciton>

		<seciton class="post">
			<div class="post-counter"></div>
			<section class="post-element">
				<div class="post-info">

					<p class="inter_link"><a href="">AI</a>,<a href="">Podcasts</a></p>
					<p class="inter_link"><a href=""><span>15</span>Conversations</a></p>
					
				</div>

				<a href="single.php"><h1>Episode 01: Artificial Intelligence</h1></a>
				<p>
					Project planning and time tracking software for architects.
				</p>
			</section>

		</seciton>

		<seciton class="post">
			<div class="post-counter"></div>
			<section class="post-element">

				<div class="post-info">

					<p class="inter_link"><a href="">AI</a> <a href="">Podcasts</a></p>
					<p class="inter_link"><a href=""><span>15</span>Conversations</a></p>
					
				</div>

				<a href="single.php"><h1>Episode 02: AI - Machine Intelligence</h1></a>
				<p>
					Project planning and time tracking software for architects.
				</p>
			</section>

		</seciton>

	</article>


	<!-- <section class="sidemenu">
		<section class="sidebar">
			<h2>Sidebar Title 1</h2>
			<hr>
			<ul>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
			</ul>
		</section>
		<section class="sidebar">
			<h2>Sidebar Title 2</h2>
			<hr>
			<ul>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
			</ul>
		</section>
		<section class="sidebar">
			<h2>Sidebar Title 3</h2>
			<hr>
			<ul>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
				<li><a href="">link</a></li>
			</ul>
		</section>
	</section> -->


	<section class="panel">

		<section class="pagination">
			<p class="inter_link"><a href="">Older Articles</a></p>
			<p class="inter_link"><a href="">Newer Articles</a></p>
		</section>

	</section>
	

<?php get_footer(); ?>